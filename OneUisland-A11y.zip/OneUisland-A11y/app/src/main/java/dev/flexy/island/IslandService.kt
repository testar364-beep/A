package dev.flexy.island

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class IslandService : AccessibilityService(), IslandView.Host {

    companion object {
        @Volatile var instance: IslandService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var lp: WindowManager.LayoutParams
    private val h = Handler(Looper.getMainLooper())

    private val items = LinkedHashMap<String, IslandItem>()
    private val expire = HashMap<String, Runnable>()
    private var current: IslandItem? = null
    private var view: IslandView? = null
    private var attached = false
    private var started = false

    private val collapse = Runnable {
        val v = view; val c = current
        if (v != null && c != null && attached) v.setExpanded(false, c)
    }

    private val prefL = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    // ---------- ciclo de vida ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (started) return
        started = true
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("island", Context.MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefL)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            title = "DynamicIsland"
        }
        startBattery()
        startTorch()
        startMedia()
    }

    override fun onUnbind(intent: Intent?): Boolean { cleanup(); return super.onUnbind(intent) }
    override fun onDestroy() { cleanup(); super.onDestroy() }
    override fun onInterrupt() {}

    private fun cleanup() {
        if (!started) return
        started = false
        instance = null
        try { prefs.unregisterOnSharedPreferenceChangeListener(prefL) } catch (_: Exception) {}
        try { unregisterReceiver(battery) } catch (_: Exception) {}
        try { getSystemService(CameraManager::class.java).unregisterTorchCallback(torchCb) } catch (_: Exception) {}
        try { getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(sessL) } catch (_: Exception) {}
        controllers.forEach { try { it.unregisterCallback(mcb) } catch (_: Exception) {} }
        controllers = emptyList()
        h.removeCallbacksAndMessages(null)
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null; attached = false
        items.clear(); expire.clear(); current = null
    }

    // ---------- fila de itens ----------

    private fun put(item: IslandItem) {
        items.remove(item.key)
        items[item.key] = item
        expire.remove(item.key)?.let { h.removeCallbacks(it) }
        if (item.ttl > 0) {
            val r = Runnable { remove(item.key) }
            expire[item.key] = r
            h.postDelayed(r, item.ttl)
        }
        refresh()
    }

    private fun remove(key: String) {
        items.remove(key)
        expire.remove(key)?.let { h.removeCallbacks(it) }
        refresh()
    }

    private fun refresh() {
        val top = items.values.withIndex()
            .maxWithOrNull(compareBy({ it.value.priority }, { it.index }))?.value
        if (top == null) { current = null; hide(); return }

        val fresh = !attached
        val v = attach()
        val keyChanged = current?.key != top.key
        current = top
        v.setExpanded(if (keyChanged) false else v.expanded, top)
        if (fresh) v.animateIn()
    }

    private fun attach(): IslandView {
        if (attached) return view!!
        val v = IslandView(this, this)
        lp.y = topY()
        try { wm.addView(v, lp) } catch (_: Exception) {}
        view = v
        attached = true
        return v
    }

    private fun hide() {
        val v = view ?: return
        if (!attached) return
        attached = false
        view = null
        h.removeCallbacks(collapse)
        v.animateOut { try { wm.removeView(v) } catch (_: Exception) {} }
    }

    private fun topY(): Int {
        val d = resources.displayMetrics.density
        val off = (prefs.getInt("offset", 0) * d).toInt()
        val cut = try { wm.currentWindowMetrics.windowInsets.displayCutout } catch (_: Exception) { null }
        val r = cut?.boundingRects?.firstOrNull { it.top <= 2 }
        val base = if (r != null) r.centerY() - (18 * d).toInt() else (8 * d).toInt()
        return maxOf(0, base + off)
    }

    private fun applyPrefs() {
        if (!started) return
        if (!prefs.getBoolean("media", true)) remove("media") else updateMedia()
        if (!prefs.getBoolean("charge", true)) remove("charge")
        if (!prefs.getBoolean("torch", true)) remove("torch")
        if (attached) { lp.y = topY(); try { wm.updateViewLayout(view, lp) } catch (_: Exception) {} }
    }

    // ---------- toques ----------

    override fun onTap() {
        val c = current ?: return
        val v = view ?: return
        val e = !v.expanded
        v.setExpanded(e, c)
        h.removeCallbacks(collapse)
        if (e) h.postDelayed(collapse, 6000)
    }

    override fun onLong() {
        val pkg = current?.pkg ?: return
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(it) } catch (_: Exception) {}
        }
    }

    fun demo() {
        put(IslandItem("demo", 90, "Dynamic Island", "Funcionando via acessibilidade ✔", glyph = "✨", ttl = 4000))
    }

    // ---------- notificações (eventos de acessibilidade) ----------

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!started || e.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        if (!prefs.getBoolean("notif", true)) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return

        val n = e.parcelableData as? Notification
        if (n != null) {
            val f = n.flags
            if ((f and Notification.FLAG_ONGOING_EVENT) != 0 || (f and Notification.FLAG_GROUP_SUMMARY) != 0) return
            if (n.category == Notification.CATEGORY_TRANSPORT) return
        }
        val ex = n?.extras
        val t = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val b = (ex?.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex?.getCharSequence(Notification.EXTRA_TEXT))?.toString()
        val fallback = e.text.joinToString(" ") { it }
        val label = appLabel(pkg)
        val title = if (t.isNullOrBlank()) label else t
        val body = if (b.isNullOrBlank()) fallback else b
        if (title.isBlank() && body.isBlank()) return

        val actions = ArrayList<IslandAction>()
        n?.contentIntent?.let { pi ->
            actions.add(IslandAction("Abrir") {
                try { pi.send() } catch (_: Exception) {}
                remove("n:$pkg")
            })
        }
        put(IslandItem("n:$pkg", 60, title, body, icon = appIcon(pkg), pkg = pkg, ttl = 5000, actions = actions))
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun appIcon(pkg: String): Drawable? = try { packageManager.getApplicationIcon(pkg) } catch (_: Exception) { null }

    // ---------- carregando ----------

    private var lastPlugged: Boolean? = null

    private val battery = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { handleBattery(i) }
    }

    private fun startBattery() {
        val sticky = registerReceiver(battery, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) lastPlugged = sticky.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
    }

    private fun handleBattery(i: Intent) {
        if (!prefs.getBoolean("charge", true)) return
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val pct = level * 100 / scale
        val prev = lastPlugged
        lastPlugged = plugged
        if (prev != null && plugged && !prev) {
            put(IslandItem("charge", 40, "Carregando", glyph = "⚡", trailing = "$pct%", ttl = 3500))
        } else if (!plugged) {
            remove("charge")
        } else if (items.containsKey("charge")) {
            val old = items["charge"]!!
            put(IslandItem("charge", 40, old.title, glyph = old.glyph, trailing = "$pct%", ttl = 2500))
        }
    }

    // ---------- lanterna ----------

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (!prefs.getBoolean("torch", true)) return
            if (enabled) {
                put(IslandItem("torch", 30, "Lanterna", glyph = "🔦", trailing = "ON",
                    actions = listOf(IslandAction("Desligar") {
                        try { getSystemService(CameraManager::class.java).setTorchMode(cameraId, false) } catch (_: Exception) {}
                    })))
            } else remove("torch")
        }
    }

    private fun startTorch() {
        try { getSystemService(CameraManager::class.java).registerTorchCallback(torchCb, h) } catch (_: Exception) {}
    }

    // ---------- mídia ----------

    private var controllers: List<MediaController> = emptyList()

    private val mcb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { updateMedia() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { updateMedia() }
    }

    private val sessL = MediaSessionManager.OnActiveSessionsChangedListener { list -> onSessions(list ?: emptyList()) }

    private fun listenerEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    /** Chame de novo (ex.: ao abrir o app) depois de liberar o acesso às notificações. */
    fun startMedia() {
        if (!listenerEnabled()) return
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, MediaListener::class.java)
            msm.removeOnActiveSessionsChangedListener(sessL)
            msm.addOnActiveSessionsChangedListener(sessL, cn, h)
            onSessions(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {}
    }

    private fun onSessions(list: List<MediaController>) {
        controllers.forEach { try { it.unregisterCallback(mcb) } catch (_: Exception) {} }
        controllers = list
        list.forEach { it.registerCallback(mcb, h) }
        updateMedia()
    }

    private fun updateMedia() {
        if (!started) return
        if (!prefs.getBoolean("media", true)) { remove("media"); return }
        val c = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        if (c == null) { remove("media"); return }
        val m = c.metadata
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Reproduzindo"
        val artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val icon: Drawable? = if (bmp != null) BitmapDrawable(resources, bmp) else appIcon(c.packageName)
        val tc = c.transportControls
        put(IslandItem("media", 20, title, artist, trailing = "♫", icon = icon, pkg = c.packageName,
            actions = listOf(
                IslandAction("⏮") { tc.skipToPrevious() },
                IslandAction("⏸") { tc.pause() },
                IslandAction("⏭") { tc.skipToNext() }
            )))
    }
}
