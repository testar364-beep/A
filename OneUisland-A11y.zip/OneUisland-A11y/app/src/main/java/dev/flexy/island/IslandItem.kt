package dev.flexy.island

import android.graphics.drawable.Drawable

class IslandAction(val label: String, val run: () -> Unit)

class IslandItem(
    val key: String,
    val priority: Int,
    val title: String,
    val subtitle: String = "",
    val trailing: String = "",
    val glyph: String? = null,
    val icon: Drawable? = null,
    val pkg: String? = null,
    val ttl: Long = 0L,
    val actions: List<IslandAction> = emptyList()
)
