package dev.flexy.island

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Mola amortecida (massa 1). */
private class Spring(var v: Float, var t: Float, val k: Float, val c: Float) {
    var vel = 0f
    fun step(dt: Float): Boolean {
        var left = dt
        while (left > 0f) {
            val h = minOf(left, 0.004f)
            vel += (-k * (v - t) - c * vel) * h
            v += vel * h
            left -= h
        }
        if (abs(v - t) < 0.5f && abs(vel) < 8f) { v = t; vel = 0f; return false }
        return true
    }
}

/**
 * Comportamento copiado do vídeo "Galaxy Island":
 *  - fechada: bolha preta à esquerda do furo da câmera + bolinha à direita (2 itens)
 *  - abrir: conteúdo some, a bolha preta cresce com mola até virar um cartão largo,
 *    o fundo vira vidro escuro e o conteúdo novo entra com atraso; bolinha da direita some
 *  - itens extras viram cartões empilhados embaixo
 *  - fechar: conteúdo some rápido, cartão encolhe pro furo, bolinha "pula" de volta
 */
class IslandView(ctx: Context, private val host: Host) : FrameLayout(ctx) {

    interface Host { fun onTap(); fun onLong(); fun setWindowWidth(px: Int) }

    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val d = ctx.resources.displayMetrics.density
    private val screenW = ctx.resources.displayMetrics.widthPixels
    private fun dp(v: Int) = (v * d).toInt()

    private val camHalf = dp(14)
    private val gap = dp(8)
    private val compactH = dp(32)

    private val bg = GradientDrawable().apply { setColor(Color.BLACK); setStroke(dp(1), 0x33FFFFFF) }
    private val blob = FrameLayout(ctx)
    private val glass = View(ctx)
    private val compact = LinearLayout(ctx)
    private val expandedBox = FrameLayout(ctx)
    private val extras = LinearLayout(ctx)
    private val lobe2 = FrameLayout(ctx)

    private val sw = Spring(dp(28).toFloat(), dp(28).toFloat(), 520f, 28f)
    private val sh = Spring(dp(28).toFloat(), dp(28).toFloat(), 520f, 28f)
    private val sx = Spring(0f, 0f, 520f, 28f)
    private var running = false
    private var lastNs = 0L
    private var lastKey: String? = null
    private var leaving = false
    private var items: List<IslandItem> = emptyList()
    private var expH = dp(72)
    private var curWinW = 0
    private var wantWinW = 0

    var expanded = false
        private set

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            val dt = if (lastNs == 0L) 1f / 60f else ((ns - lastNs) / 1e9f).coerceIn(0.001f, 1f / 30f)
            lastNs = ns
            val a = sw.step(dt)
            val b = sh.step(dt)
            val c = sx.step(dt)
            applyFrame()
            if (a || b || c) Choreographer.getInstance().postFrameCallback(this)
            else { running = false; lastNs = 0L }
        }
    }

    private fun kick() {
        if (!running) { running = true; Choreographer.getInstance().postFrameCallback(frame) }
    }

    private fun applyFrame() {
        val w = sw.v.toInt().coerceAtLeast(dp(8))
        val h = sh.v.toInt().coerceAtLeast(dp(8))
        val lp = blob.layoutParams as LayoutParams
        lp.width = w; lp.height = h
        blob.layoutParams = lp
        blob.translationX = sx.v
        bg.cornerRadius = minOf(dp(28).toFloat(), h / 2f)
        val span = (expH - compactH).toFloat()
        glass.alpha = if (span > 0f) ((sh.v - compactH) / span).coerceIn(0f, 1f) else 0f
        val ep = extras.layoutParams as LayoutParams
        ep.topMargin = h + gap
        extras.layoutParams = ep
    }

    init {
        blob.background = bg
        blob.clipToOutline = true
        blob.isClickable = true
        blob.setOnClickListener { host.onTap() }
        blob.setOnLongClickListener { host.onLong(); true }
        blob.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ -> v.pivotX = v.width / 2f; v.pivotY = v.height / 2f }
        blob.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(120).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
        glass.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xF2101026.toInt(), 0xF22F2480.toInt())
        )
        glass.alpha = 0f
        blob.addView(glass, LayoutParams(-1, -1))
        blob.addView(compact, LayoutParams(WRAP, compactH, Gravity.CENTER))
        blob.addView(expandedBox, LayoutParams(WRAP, WRAP, Gravity.CENTER))
        expandedBox.alpha = 0f

        extras.orientation = LinearLayout.VERTICAL
        extras.alpha = 0f

        lobe2.background = GradientDrawable().apply { setColor(Color.BLACK); setStroke(dp(1), 0x33FFFFFF); shape = GradientDrawable.OVAL }
        lobe2.isClickable = true
        lobe2.setOnClickListener { host.onTap() }
        lobe2.visibility = View.GONE

        addView(blob, LayoutParams(dp(28), dp(28), Gravity.CENTER_HORIZONTAL))
        addView(extras, LayoutParams(dp(200), WRAP, Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(40) })
        addView(lobe2, LayoutParams(compactH, compactH, Gravity.CENTER_HORIZONTAL).apply { })
    }

    // ---------- construção do conteúdo ----------

    private fun iconView(item: IslandItem, sizeDp: Int): View {
        val s = dp(sizeDp)
        return if (item.icon != null) {
            ImageView(context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageDrawable(item.icon)
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, s * 0.25f)
                    }
                }
                layoutParams = LinearLayout.LayoutParams(s, s)
            }
        } else {
            TextView(context).apply {
                text = item.glyph ?: "●"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_PX, s * 0.7f)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(s, s)
            }
        }
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean, lines: Int) = TextView(context).apply {
        this.text = text
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        maxLines = lines
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun roundBtn(a: IslandAction) = TextView(context).apply {
        text = a.label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x40FFFFFF) }
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) }
        setOnClickListener { a.run() }
    }

    private fun card(item: IslandItem): View {
        val media = item.key == "media"
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(iconView(item, if (media) 56 else 40))
        val texts = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(item.title, 15f, Color.WHITE, true, 1))
        if (item.subtitle.isNotEmpty()) texts.addView(label(item.subtitle, 12f, 0xB3FFFFFF.toInt(), false, if (media) 1 else 3))
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14); marginEnd = dp(10) })
        if (item.trailing.isNotEmpty()) row.addView(label(item.trailing, 15f, Color.WHITE, true, 1))
        if (!media) item.actions.forEach { row.addView(roundBtn(it)) }
        box.addView(row, LinearLayout.LayoutParams(-1, WRAP))
        if (media && item.actions.isNotEmpty()) {
            val ctl = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            item.actions.forEach { a ->
                ctl.addView(TextView(context).apply {
                    text = a.label; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                    setPadding(dp(20), dp(6), dp(20), dp(6)); setOnClickListener { a.run() }
                })
            }
            box.addView(ctl, LinearLayout.LayoutParams(-1, WRAP).apply { topMargin = dp(6) })
        }
        return box
    }

    private fun rebuild() {
        val p = items[0]
        val split = items.size >= 2

        compact.removeAllViews()
        compact.orientation = LinearLayout.HORIZONTAL
        compact.gravity = Gravity.CENTER_VERTICAL
        compact.setPadding(dp(8), 0, dp(12), 0)
        compact.addView(iconView(p, 24))
        if (!split) compact.addView(View(context), LinearLayout.LayoutParams(camHalf * 2, 1))
        compact.addView(label(p.title, 13f, Color.WHITE, true, 1).apply { maxWidth = dp(110) },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        if (p.trailing.isNotEmpty())
            compact.addView(label(p.trailing, 13f, Color.WHITE, false, 1), LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })

        expandedBox.removeAllViews()
        expandedBox.addView(card(p))

        extras.removeAllViews()
        items.drop(1).forEachIndexed { i, it ->
            val c = card(it)
            c.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xF2101026.toInt(), 0xF22F2480.toInt()))
                .apply { cornerRadius = dp(26).toFloat(); setStroke(dp(1), 0x22FFFFFF) }
            extras.addView(c, LinearLayout.LayoutParams(-1, WRAP).apply { if (i > 0) topMargin = gap })
        }

        lobe2.removeAllViews()
        if (split) {
            val it = items[1]
            lobe2.addView(iconView(it, 20).apply { layoutParams = LayoutParams(dp(20), dp(20), Gravity.CENTER) })
        }
        lobe2.translationX = (camHalf + dp(2) + compactH / 2f)
    }

    // ---------- API ----------

    fun setItems(list: List<IslandItem>) {
        if (list.isEmpty() || leaving) return
        val key = list[0].key
        val swap = lastKey != null && lastKey != key
        lastKey = key
        if (swap) expanded = false
        items = list
        rebuild()
        applyModeInstant()
        layoutTargets()
        if (swap) {
            compact.animate().cancel()
            compact.alpha = 0f
            compact.animate().alpha(1f).setStartDelay(80).setDuration(200).start()
        }
        kick()
    }

    fun setExpanded(e: Boolean) {
        if (e == expanded || leaving || items.isEmpty()) return
        expanded = e
        layoutTargets()
        animateMode()
        kick()
    }

    private fun applyModeInstant() {
        val split = items.size >= 2
        compact.alpha = if (expanded) 0f else 1f
        expandedBox.alpha = if (expanded) 1f else 0f
        extras.alpha = if (expanded) 1f else 0f
        lobe2.visibility = if (split) View.VISIBLE else View.GONE
        lobe2.alpha = if (expanded) 0f else 1f
        lobe2.scaleX = if (expanded) 0.3f else 1f
        lobe2.scaleY = lobe2.scaleX
    }

    private fun animateMode() {
        listOf(compact, expandedBox, extras, lobe2).forEach { it.animate().cancel() }
        if (expanded) {
            compact.animate().alpha(0f).setStartDelay(0).setDuration(70).start()
            lobe2.animate().alpha(0f).scaleX(0.3f).scaleY(0.3f).setStartDelay(0).setDuration(120).start()
            expandedBox.animate().alpha(1f).setStartDelay(200).setDuration(200).start()
            extras.animate().alpha(1f).setStartDelay(260).setDuration(200).start()
        } else {
            expandedBox.animate().alpha(0f).setStartDelay(0).setDuration(80).start()
            extras.animate().alpha(0f).setStartDelay(0).setDuration(80).start()
            compact.animate().alpha(1f).setStartDelay(170).setDuration(180).start()
            lobe2.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(190).setDuration(300)
                .setInterpolator(OvershootInterpolator(2.2f)).start()
        }
    }

    private fun layoutTargets() {
        val split = items.size >= 2
        val expW = screenW - dp(32)

        compact.measure(MeasureSpec.makeMeasureSpec(screenW, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(compactH, MeasureSpec.EXACTLY))
        val cw = maxOf(compact.measuredWidth, compactH)
        compact.layoutParams = LayoutParams(cw, compactH, Gravity.CENTER)

        expandedBox.measure(MeasureSpec.makeMeasureSpec(expW, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        expH = maxOf(expandedBox.measuredHeight, dp(64))
        expandedBox.layoutParams = LayoutParams(expW, expH, Gravity.CENTER)

        val ep = LayoutParams(expW, WRAP, Gravity.CENTER_HORIZONTAL or Gravity.TOP)
        extras.layoutParams = ep
        extras.requestLayout()

        if (expanded) {
            sw.t = expW.toFloat(); sh.t = expH.toFloat(); sx.t = 0f
        } else {
            sw.t = cw.toFloat(); sh.t = compactH.toFloat()
            sx.t = if (split) -(camHalf + cw / 2f) else 0f
        }

        val half = when {
            expanded -> expW / 2 + dp(2)
            split -> maxOf(camHalf + cw, camHalf + dp(40)) + dp(2)
            else -> cw / 2 + dp(2)
        }
        updateWindow(half * 2)
    }

    private fun updateWindow(w: Int) {
        wantWinW = w
        if (w >= curWinW) { curWinW = w; host.setWindowWidth(w) }
        else postDelayed({ if (wantWinW == w) { curWinW = w; host.setWindowWidth(w) } }, 320)
    }

    /** Nasce pequena no furo da câmera e cresce com a mola. */
    fun animateIn() {
        compact.animate().cancel(); lobe2.animate().cancel()
        compact.alpha = 0f
        compact.animate().alpha(1f).setStartDelay(120).setDuration(200).start()
        if (lobe2.visibility == View.VISIBLE) {
            lobe2.alpha = 0f; lobe2.scaleX = 0.3f; lobe2.scaleY = 0.3f
            lobe2.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(220).setDuration(300)
                .setInterpolator(OvershootInterpolator(2.2f)).start()
        }
    }

    /** Conteúdo some, cartão encolhe de volta pro furo. */
    fun animateOut(end: () -> Unit) {
        leaving = true
        listOf(compact, expandedBox, extras, lobe2).forEach { it.animate().cancel(); it.animate().alpha(0f).setStartDelay(0).setDuration(100).start() }
        sw.t = dp(28).toFloat(); sh.t = dp(28).toFloat(); sx.t = 0f
        kick()
        postDelayed({ end() }, 280)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        Choreographer.getInstance().removeFrameCallback(frame)
        running = false
    }
}
