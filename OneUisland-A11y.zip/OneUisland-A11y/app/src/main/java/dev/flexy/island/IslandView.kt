package dev.flexy.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class IslandView(ctx: Context, private val host: Host) : FrameLayout(ctx) {

    interface Host { fun onTap(); fun onLong() }

    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val d = ctx.resources.displayMetrics.density
    private val screenW = ctx.resources.displayMetrics.widthPixels
    private fun dp(v: Int) = (v * d).toInt()

    private val card = LinearLayout(ctx)
    private val iconImg = ImageView(ctx)
    private val glyph = TextView(ctx)
    private val title = TextView(ctx)
    private val sub = TextView(ctx)
    private val trailing = TextView(ctx)
    private val controls = LinearLayout(ctx)
    private var anim: ValueAnimator? = null

    var expanded = false
        private set

    init {
        card.orientation = LinearLayout.VERTICAL
        card.background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = dp(22).toFloat() }
        card.setPadding(dp(8), dp(4), dp(14), dp(4))
        card.minimumHeight = dp(36)
        card.isClickable = true
        card.setOnClickListener { host.onTap() }
        card.setOnLongClickListener { host.onLong(); true }
        card.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ -> v.pivotX = v.width / 2f; v.pivotY = 0f }

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

        val iconBox = FrameLayout(ctx)
        iconImg.scaleType = ImageView.ScaleType.CENTER_CROP
        iconImg.clipToOutline = true
        iconImg.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(7).toFloat())
            }
        }
        glyph.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        glyph.gravity = Gravity.CENTER
        glyph.setTextColor(Color.WHITE)
        iconBox.addView(iconImg, FrameLayout.LayoutParams(dp(28), dp(28)))
        iconBox.addView(glyph, FrameLayout.LayoutParams(dp(28), dp(28)))
        row.addView(iconBox, LinearLayout.LayoutParams(dp(28), dp(28)))

        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        title.typeface = Typeface.DEFAULT_BOLD
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        sub.setTextColor(0xB3FFFFFF.toInt())
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        sub.maxLines = 3
        sub.ellipsize = TextUtils.TruncateAt.END
        sub.visibility = View.GONE
        val texts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(title)
        texts.addView(sub)
        row.addView(texts, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(10); marginEnd = dp(10) })

        trailing.setTextColor(Color.WHITE)
        trailing.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        row.addView(trailing)

        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        controls.visibility = View.GONE

        card.addView(row)
        card.addView(controls)
        addView(card, LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL))
    }

    fun setExpanded(e: Boolean, item: IslandItem) { expanded = e; bind(item) }

    fun bind(item: IslandItem) {
        if (item.icon != null) {
            iconImg.setImageDrawable(item.icon); iconImg.visibility = View.VISIBLE; glyph.visibility = View.GONE
        } else {
            iconImg.visibility = View.GONE; glyph.text = item.glyph ?: "●"; glyph.visibility = View.VISIBLE
        }
        title.text = item.title
        title.maxWidth = if (expanded) dp(250) else dp(150)
        sub.text = item.subtitle
        sub.maxWidth = dp(250)
        sub.visibility = if (expanded && item.subtitle.isNotEmpty()) View.VISIBLE else View.GONE
        trailing.text = item.trailing
        trailing.visibility = if (item.trailing.isEmpty()) View.GONE else View.VISIBLE

        controls.removeAllViews()
        item.actions.forEach { a ->
            controls.addView(TextView(context).apply {
                text = a.label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                setPadding(dp(18), dp(6), dp(18), dp(6))
                setOnClickListener { a.run() }
            })
        }
        controls.visibility = if (expanded && item.actions.isNotEmpty()) View.VISIBLE else View.GONE
        resize()
    }

    private fun resize() {
        val from = if (card.width > 0) card.width else dp(36)
        card.layoutParams = LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL)
        card.measure(
            MeasureSpec.makeMeasureSpec(screenW - dp(24), MeasureSpec.AT_MOST),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        )
        val natural = card.measuredWidth
        val to = if (expanded) maxOf(natural, minOf(dp(340), screenW - dp(24))) else natural
        anim?.cancel()
        anim = ValueAnimator.ofInt(from, to).apply {
            duration = 350
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener {
                val lp = card.layoutParams as LayoutParams
                lp.width = it.animatedValue as Int
                card.layoutParams = lp
            }
            start()
        }
    }

    fun animateIn() {
        card.alpha = 0f; card.scaleX = 0.5f; card.scaleY = 0.5f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300)
            .setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    fun animateOut(end: () -> Unit) {
        card.animate().alpha(0f).scaleX(0.5f).scaleY(0.5f).setDuration(200).withEndAction(end).start()
    }
}
