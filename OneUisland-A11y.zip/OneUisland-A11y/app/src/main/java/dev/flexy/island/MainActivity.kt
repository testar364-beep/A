package dev.flexy.island

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("island", Context.MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        col.addView(TextView(this).apply { text = "Dynamic Island"; textSize = 26f; setTextColor(Color.WHITE) })
        status = TextView(this).apply { textSize = 14f; setTextColor(0xFFBBBBBB.toInt()); setPadding(0, dp(8), 0, dp(12)) }
        col.addView(status)

        col.addView(btn("1) Ativar serviço de acessibilidade") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("Se estiver bloqueado: Info do app → ⋮ → Permitir configurações restritas") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2) Liberar mídia (acesso às notificações)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(btn("Testar ilha") {
            val s = IslandService.instance
            if (s == null) status.text = "Serviço de acessibilidade desligado." else s.demo()
        })

        listOf("media" to "Mídia", "notif" to "Notificações", "charge" to "Carregando", "torch" to "Lanterna").forEach { (k, label) ->
            col.addView(CheckBox(this).apply {
                text = label; setTextColor(Color.WHITE)
                isChecked = prefs.getBoolean(k, true)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(k, on).apply() }
            })
        }

        col.addView(TextView(this).apply { text = "Posição vertical (ajuste fino)"; setTextColor(Color.WHITE); setPadding(0, dp(16), 0, 0) })
        col.addView(SeekBar(this).apply {
            max = 60
            progress = prefs.getInt("offset", 0) + 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt("offset", p - 20).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) })
    }

    override fun onResume() {
        super.onResume()
        IslandService.instance?.startMedia()
        val a11y = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        val nl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = "Acessibilidade: ${if (a11y) "ligada ✔" else "desligada ✘"}\n" +
            "Acesso para mídia: ${if (nl) "liberado ✔" else "pendente ✘"}"
    }

    private fun btn(t: String, click: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
    }
}
