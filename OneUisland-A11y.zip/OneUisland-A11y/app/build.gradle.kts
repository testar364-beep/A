plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "dev.flexy.island"
    compileSdk = 35
    defaultConfig {
        applicationId = "dev.flexy.dynamicisland.a11y"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "2.0-a11y"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
