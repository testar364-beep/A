# Dynamic Island (versão acessibilidade)

Reescrita do OneUisland v1.4.5 sem Xposed/root.

## Como gerar o APK
1. Abra a pasta no Android Studio (Ladybug ou mais novo) e espere o Gradle sincronizar.
2. Build > Build APK(s). Saída: app/build/outputs/apk/debug/app-debug.apk
3. Instale no celular.

## Como ativar
1. Abra o app → "Ativar serviço de acessibilidade" → Dynamic Island → ligar.
   (Android 13+: se estiver cinza, Info do app → ⋮ → Permitir configurações restritas.)
2. Para a ilha de música: "Liberar mídia" → ligar Dynamic Island.
3. "Testar ilha" para conferir.

## O que tem
- Mídia: capa, título, anterior/pausar/próxima (toque expande, toque longo abre o app)
- Notificações (toque expande e mostra o texto + botão Abrir)
- Carregando (ao plugar o cabo) e Lanterna (com botão Desligar)
- Posição automática no furo da câmera + ajuste fino
