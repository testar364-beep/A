package dev.flexy.island

import android.service.notification.NotificationListenerService

/** Vazio de propósito: o acesso às notificações só é necessário para o Android liberar getActiveSessions(). */
class MediaListener : NotificationListenerService()
